package com.cts.hibernate.HibernateProj;


import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.cts.model.OrderItem;

public class App 
{
	public static void main( String[] args ) {

		Configuration config = new Configuration().configure();
		StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder().applySettings(config.getProperties());
		SessionFactory factory = config.buildSessionFactory(builder.build());
		Session session = factory.openSession();

		//		    	OrderItem order = new OrderItem(1005, 5, 10, 8004, 15, 3700.435f);
		//		    	
		//		    	session.beginTransaction();
		//		    	session.save(order);
		//		    	session.refresh(order);
		//		    	session.getTransaction().commit();
		//		    	session.close();

		//    	String hql = "FROM OrderItem";
		//    	Query query = session.createQuery(hql);
		//    	List<OrderItem> l1 = query.list();
		//    	System.out.println(l1);

		//    	String qry = "SELECT order.productId FROM OrderItem order";
		//    	Query query = session.createQuery(qry);
		//    	List<OrderItem> l2 = query.list();
		//    	System.out.println(l2);

		//		String qry = "FROM OrderItem order WHERE order.id = :id";
		//		Query query = session.createQuery(qry).setParameter("id",1001);
		//		List<OrderItem> l3 = query.list();
		//		System.out.println(l3);

		//		OrderItem order = new OrderItem();
		//		order.setProductId(8003);
		//		String qry = "FROM OrderItem order WHERE order.productId = :productId";
		//		List l4 = session.createQuery(qry).setProperties(order).list();
		//		System.out.println(l4);

		//		Query query = session.createSQLQuery("SELECT COUNT(*) FROM order_item");
		//		System.out.println(query.list());

		//		Query query = session.getNamedQuery("retriveAll");
		//		List<OrderItem> l1 = query.setFirstResult(0).setFetchSize(2).list();
		//		System.out.println(l1);
		//		
		//		Query query2 = session.getNamedQuery("retriveCount");
		//		System.out.println(query2.list());

		



	}
}
