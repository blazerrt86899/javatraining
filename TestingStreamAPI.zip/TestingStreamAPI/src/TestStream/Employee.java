package TestStream;

public class Employee {

	private int id;
	private String name;
	private String location;
	private Double salary;
	private String desig;

	public Employee() {
		// TODO Auto-generated constructor stub
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public String getDesig() {
		return desig;
	}
	public void setDesig(String desig) {
		this.desig = desig;
	}

	public Employee(int id, String name, String location, Double salary, String desig) {
		super();
		this.id = id;
		this.name = name;
		this.location = location;
		this.salary = salary;
		this.desig = desig;
	}


}
