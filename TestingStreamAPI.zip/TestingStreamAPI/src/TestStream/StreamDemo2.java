package TestStream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class StreamDemo2 {

	public static void main(String[] args) {
		
		List<Employee> emp = new ArrayList<>();
		emp.add(new Employee(234,"Romu","MH",3459.45,"Architect"));
		emp.add(new Employee(235,"Raju","ALD",6459.45,".NET Developer"));
		emp.add(new Employee(236,"Amit","MH",3559.45,".NET Developer"));
		emp.add(new Employee(237,"Ajay","CH",3759.45,"FSE-Developer"));
		emp.add(new Employee(238,"Rahul","CH",8459.45,"FSE-Developer"));

	}
	
	
	
	
	

}
