package com.example.jpa.repository;


import com.example.jpa.model.NewComment;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Created by rajeevkumarsingh on 21/11/17.
 */
@Repository
public interface NewCommentRepository extends JpaRepository<NewComment, Long> {
    Page<NewComment> findByPostId(Long postId, Pageable pageable);
    Optional<NewComment> findByIdAndPostId(Long id, Long postId);
}
