package com.cts.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CollectionId;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

@Entity
public class UserDetail {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String name;
	private String address;
	@Temporal(TemporalType.DATE)
	private Date joinedDate;
	private String description;
	@Embedded
	@ElementCollection
	@JoinTable(name="USER_ADDRESS",
				joinColumns = @JoinColumn(name="USER_ID"))
	@GenericGenerator(name="hilo-gen",strategy = "hilo")
	@CollectionId(columns = @Column(name = "ADDRESS_ID"), generator = "hilo-gen",type = @Type(type="long"))
	private Collection<Address> addr = new ArrayList<Address>();
//	@ElementCollection
//	private Set<Address> addr = new HashSet<Address>();
//	@AttributeOverrides({
//		@AttributeOverride(name="street",column = @Column(name="HOME_STREET_NAME")),
//		@AttributeOverride(name="city",column = @Column(name="HOME_CITY_NAME")),
//		@AttributeOverride(name="pincode",column = @Column(name="HOME_PIN_CODE")),
//		@AttributeOverride(name="state",column = @Column(name="HOME_STATE_NAME"))
//	})
//	private Address homeAddr;
//	
//	@Embedded
//	private Address officeAddr;
	
	
	
	
//	public Address getHomeAddr() {
//		return homeAddr;
//	}
//	public void setHomeAddr(Address homeAddr) {
//		this.homeAddr = homeAddr;
//	}
//	public Address getOfficeAddr() {
//		return officeAddr;
//	}
//	public void setOfficeAddr(Address officeAddr) {
//		this.officeAddr = officeAddr;
//	}
	
//	public Set<Address> getAddr() {
//		return addr;
//	}
//	public void setAddr(Set<Address> addr) {
//		this.addr = addr;
//	}
	
	public Collection<Address> getAddr() {
		return addr;
	}
	
	public void setAddr(Collection<Address> addr) {
		this.addr = addr;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Date getJoinedDate() {
		return joinedDate;
	}
	public void setJoinedDate(Date joinedDate) {
		this.joinedDate = joinedDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	 public UserDetail() {
		// TODO Auto-generated constructor stub
	}
	
	public UserDetail(int id, String name, String address, Date joinedDate, String description) {
		this.id = id;
		this.name = name;
		this.address = address;
		this.joinedDate = joinedDate;
		this.description = description;
	}
	@Override
	public String toString() {
		return "UserDetail [id=" + id + ", name=" + name + ", address=" + address + ", joinedDate=" + joinedDate
				+ ", description=" + description + "]";
	}
	
	
	
	
	

}
