package com.cts.Hibernate.HibernateBasics;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.cts.model.Address;
import com.cts.model.UserDetail;

public class App {

	public static void main(String[] args) {
		
		Configuration config = new Configuration().configure();
		StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder().applySettings(config.getProperties());
		SessionFactory factory = config.buildSessionFactory(builder.build());
		Session session = factory.openSession();
		
		//UserDetail
		UserDetail userDetail  = new UserDetail(1001,"Abhishek", "Perungudi", new Date(), "Kishor");
//		UserDetail userDetail2  = new UserDetail(1002,"Romu", "Thoraipakkam", new Date(), "Nithin");
		
		//Address Value Object
		Address addr = new Address();
		Address addr1 = new Address();
		
		addr.setCity("Chennai");
		addr.setPincode(600096);
		addr.setState("Tamil Nadu");
		addr.setStreet("Perungudi");
//		userDetail.setHomeAddr(addr);
	
		addr1.setCity("Bangalore");
		addr1.setPincode(569909);
		addr1.setState("Karnataka");
		addr1.setStreet("Sarjapur");
//		userDetail2.setAddr(addr1);
//		userDetail.setOfficeAddr(addr1);
		userDetail.getAddr().add(addr);
		userDetail.getAddr().add(addr1);
		//Transaction
		session.beginTransaction();
		session.save(userDetail);
//		session.save(userDetail2);
		session.getTransaction().commit();
		session.close();
		
//		session = factory.openSession();
//		session.getTransaction().begin();
//		userDetail = (UserDetail)session.get(UserDetail.class, 1001);
//		session.getTransaction().commit();
//		System.out.println(userDetail);
//		session.close();
		

	}

}
