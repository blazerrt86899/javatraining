package com.cts.pms.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.pms.model.Product;
import com.cts.pms.model.ProductService;

@Controller
public class HomeController {
	@Autowired
	ProductService serv;
	
	@RequestMapping("/")
	public String getProductPage(Model model) {
		Product product = new Product();
		model.addAttribute("product",product);
		return "index";
		
	}
	
//	@RequestMapping(value="process.do",method=RequestMethod.POST)
//	public ModelAndView ProductPage(Model model,@ModelAttribute("product") Product product) {
//		ModelAndView modelAndView = new ModelAndView("success");
//		modelAndView.addObject("prodObj",product);
//		return modelAndView;
//	}
	
	@RequestMapping(value="process.do",method=RequestMethod.POST)
	public ModelAndView ProductPage(@Valid @ModelAttribute("product") Product product,BindingResult br) {
		String path=null;
		ModelAndView modelAndView = new ModelAndView();
		if(br.hasErrors()) {
			path="index";
		}
		else {
			path="success";
			int pid = serv.addProduct(product);
			modelAndView.addObject("msg","Stored successfully with "+pid+" !!!");
		}
		modelAndView.setViewName(path);
		return modelAndView;
	}

}
