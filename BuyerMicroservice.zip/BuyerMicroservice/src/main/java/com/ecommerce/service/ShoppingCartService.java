package com.ecommerce.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.model.ShoppingCart;
import com.ecommerce.repository.BuyerRepository;
import com.ecommerce.repository.CartRepository;

@Service
public class ShoppingCartService {
	
	@Autowired
	private CartRepository cartRepository;
	
	@Autowired
	private BuyerRepository buyerRepository;
	
//	public List<ShoppingCart> getAllCartItems(Integer buyerId){
//		return cartRepository.findAllByBuyerId(buyerId);
//	}
	public List<ShoppingCart> getAllCartItems(Integer buyerId){
		return cartRepository.getAllCartItems(buyerId);
	}
	
	public Optional<ShoppingCart> addCartItem(ShoppingCart shoppingCartItem, Integer buyerId) {
		return buyerRepository.findById(buyerId).map(buyer -> {
			shoppingCartItem.setBuyerId(buyer);
			return cartRepository.save(shoppingCartItem);
		});
		
	}
	
	public String deleteCartItemById(Integer cartItemId) {
		cartRepository.deleteById(cartItemId);
		return "Item with cartId "+cartItemId+" is deleted.";
	}
	
	public void emptyCart(Integer buyerId) {
		//Optional<Buyer> buyerInfo = buyerRepository.findById(buyerId);
		cartRepository.emptyCart(buyerId);
	}
	
	public ShoppingCart updateCart(ShoppingCart shoppingCartItem,Integer cartItemId) {
		ShoppingCart newCart = null;
		Optional<ShoppingCart> cartItem = cartRepository.findById(cartItemId);
		
		if(cartItem.isPresent()) {
		newCart = cartItem.get();
		newCart.setItemQuantity(shoppingCartItem.getItemQuantity());
		
		return cartRepository.save(newCart);
		}
		
		return null;
		
	}
	
	
	public void checkoutCart() {
		
	}
	
	

}
