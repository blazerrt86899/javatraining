package com.ecommerce.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name = "cart_item")
public class ShoppingCart implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "cart_id")
	private Integer cartId;
	@Column(name = "item_detail")
	private ItemInventory itemInventory;
	@Column
	private Integer itemQuantity;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "buyer_id_fk")
	@OnDelete(action = OnDeleteAction.CASCADE)
	private Buyer buyerId;
	
	//No arg Constructor
	public ShoppingCart() {
		// TODO Auto-generated constructor stub
	}

	//Arg Constructor
	public ShoppingCart(Integer cartId, ItemInventory itemInventory, Integer itemQuantity, Buyer buyerId) {
		
		this.cartId = cartId;
		this.itemInventory = itemInventory;
		this.itemQuantity = itemQuantity;
		this.buyerId = buyerId;
	}

	//Getters and Setters
	public Integer getCartId() {
		return cartId;
	}


	public void setCartId(Integer cartId) {
		this.cartId = cartId;
	}


	public ItemInventory getItemInventory() {
		return itemInventory;
	}


	public void setItemInventory(ItemInventory itemInventory) {
		this.itemInventory = itemInventory;
	}


	public Integer getItemQuantity() {
		return itemQuantity;
	}


	public void setItemQuantity(Integer itemQuantity) {
		this.itemQuantity = itemQuantity;
	}


	public Buyer getBuyerId() {
		return buyerId;
	}


	public void setBuyerId(Buyer buyerId) {
		this.buyerId = buyerId;
	}


	@Override
	public String toString() {
		return "ShoppingCart [cartId=" + cartId + ", itemInventory=" + itemInventory + ", itemQuantity=" + itemQuantity
				+ ", buyerId=" + buyerId + "]";
	}
	
	
	
	
}
