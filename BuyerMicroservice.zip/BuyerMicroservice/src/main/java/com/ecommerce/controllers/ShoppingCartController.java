package com.ecommerce.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.model.ShoppingCart;
import com.ecommerce.service.ShoppingCartService;

@RestController
@RequestMapping("/cart")
public class ShoppingCartController {
	
	@Autowired
	private ShoppingCartService cartService;
	
	@GetMapping(value = "/{bid}/getAll")
	public List<ShoppingCart> getAllCartItems(@PathVariable("bid") Integer buyerId) {
		return cartService.getAllCartItems(buyerId);
	}
	
	@PostMapping(value="/{bid}/addcartitem",produces = "application/json")
	public ShoppingCart addCartItem(@PathVariable("bid") Integer buyerId,@RequestBody ShoppingCart shoppingCartItem) {
		Optional<ShoppingCart> savedItem = cartService.addCartItem(shoppingCartItem, buyerId);
		return savedItem.get();
	}
	
	@DeleteMapping(value = "/{cartitem}/deletecartitembyid")
	public String deleteCartItem(@PathVariable("cartitem") Integer cartItemId) {
		return cartService.deleteCartItemById(cartItemId);
	}
	
	@DeleteMapping(value = "/{bid}/deleteall")
	public void deleteByBuyerId(@PathVariable("bid") Integer buyerId) {
		cartService.deleteByBuyerId(buyerId);
	}

}
