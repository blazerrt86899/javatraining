package com.ecommerce.controllers;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class ShoppingCartController {

}
