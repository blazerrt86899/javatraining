package com.cts.Product;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class ProductService {
	
	@Autowired
	ProductDao pDao;
	
	public int addProduct(Product product) {
		
		return pDao.addProduct(product);
	}

}
