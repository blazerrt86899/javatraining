package com.cts.Product;

import java.util.Random;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
//import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
//import org.springframework.stereotype.Component;


public class ProductUI {

	@Autowired
	static ProductService pServ;
	static Random random;


	//	public void display() {
	//		System.out.println(pServ);
	//	}

	public static void main(String[] args) {
		Integer productId = new Integer(0);
		Scanner inputValues = new Scanner(System.in);
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		System.out.println("Welcome to Product Management System !!!!!!");
		System.out.println("Type 'Y' or 'y' to Add product to the Database.");
		char option = 'y';

		while(option =='Y' || option =='y') {

			Product product = new Product();
			random = new Random();
			product.setProdId(random.nextInt(10)+1000);
			System.out.println("Enter Name of Product: ");
			product.setProdName(inputValues.next());
			System.out.println("Enter Quantity of Product: ");
			product.setProdQuantity(inputValues.nextInt());
			System.out.println("Enter Price of Product: ");
			product.setProdPrice(inputValues.nextFloat());

			System.out.println(pServ);

			productId = pServ.addProduct(product);

			System.out.println("Product Stored successfully with product id "+productId+" !!!");

			System.out.println("Enter 'Y to continue or 'N' to stop the process....!!!!");
			option=inputValues.next().charAt(0);



		}






	}

}
