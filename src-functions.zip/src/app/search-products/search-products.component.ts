import { Component, OnInit } from '@angular/core';
import {Item} from '../customer';
import {CustomerService} from '../customer.service';
@Component({
  selector: 'app-search-products',
  templateUrl: './search-products.component.html',
  styleUrls: ['./search-products.component.css']
})
export class SearchProductsComponent implements OnInit {


  searchStr: string;
  items: Item[];

  constructor(private dataService: CustomerService) { }

  ngOnInit() {
    this.searchStr = "";
  }

  private searchCustomers() {
    this.dataService.getCustomersByString(this.searchStr)
      .subscribe(items => this.items = items);
  }

  onSubmit() {
    this.searchCustomers();
  }
}
