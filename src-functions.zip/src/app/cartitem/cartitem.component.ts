import { Component, OnInit, Input } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Item } from '../customer';


@Component({
  selector: 'app-cartitem',
  templateUrl: './cartitem.component.html',
  styleUrls: ['./cartitem.component.css']
})
export class CartitemComponent implements OnInit {

  items: Item[];
  sellerid : number;
  constructor(private serv : CustomerService) { }

  ngOnInit(): void {
  }

  onClicking(){
    this.serv.getItemList(this.sellerid).subscribe(items =>{this.items = items})
  }

}
