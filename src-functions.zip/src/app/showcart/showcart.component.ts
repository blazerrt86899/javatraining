import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { ViewCart } from '../customer';
import { Router } from '@angular/router';

@Component({
  selector: 'app-showcart',
  templateUrl: './showcart.component.html',
  styleUrls: ['./showcart.component.css']
})
export class ShowcartComponent implements OnInit {


  constructor(private cartservice : CustomerService, private router : Router) { }

  viewCart : ViewCart = new ViewCart();
  view : ViewCart[];
  success : String;
  totalAmount:number = 0;

  ngOnInit(): void {

    this.cartservice.viewCart().subscribe(itemview => this.view = itemview)
        
      
  }

  increment(cartView : ViewCart){
    cartView.itemQuantity += 1;
    this.cartservice.updateCart(cartView).subscribe(newView => this.viewCart = newView);
  }

  decrement(cartView : ViewCart){
    cartView.itemQuantity -= 1;
    this.cartservice.updateCart(cartView).subscribe(newView => this.viewCart = newView);
  }

  deleteCart(cartId : number){
    this.cartservice.deleteCart(cartId).subscribe(()=> this.viewCartComponent());
    //this.router.navigateByUrl("/showcart");
  }

  viewCartComponent(){

    this.cartservice.viewCart().subscribe(itemview => this.view = itemview);
  }

  // checkoutCart(){
  //   this.cartservice.checkoutCart();
  // }

}
