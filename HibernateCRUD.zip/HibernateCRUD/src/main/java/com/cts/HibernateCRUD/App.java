package com.cts.HibernateCRUD;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.cts.model.UserDetails;


public class App 
{
    public static void main( String[] args ) {
    	UserDetails user = new UserDetails();
    	
    	Configuration config = new Configuration().configure();
    	StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder().applySettings(config.getProperties());
    	SessionFactory factory = config.buildSessionFactory(builder.build());
    	Session session =factory.openSession();
    	
    	session.getTransaction().begin();
//    	for(int i=1;i<=10;i++) {
//    		UserDetails user = new UserDetails();
//    		user.setUserName("User " + i);
//    		session.save(user);
//    	}
//    	UserDetails user = (UserDetails) session.get(UserDetails.class, 4);
//    	user.setUserName("Updated User");
//    	session.update(user);
//    	session.delete(user);
//    	System.out.println("Updated User is: "+user.getUserName());
    	user.setUserName("User 1");
    	session.save(user);
    	
    	
    	session.getTransaction().commit();
    	session.close();
    	
    	

    }
}
