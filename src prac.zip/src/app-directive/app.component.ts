import { Component } from '@angular/core';
import { User } from './user';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
//isValid = true;
 ids = [1,2,3,4];
 title = 'app';
 count:number = 0;

func(){

// if(this.isValid){
//   this.isValid = false;
// }
// else{
//   this.isValid = true;
// }
 // this.isValid = (this.isValid) ? false : true ;
 // this.isValid = !this.isValid;
this.count++;

 }

 users: User[] = [
  new User('Mahesh', 20, "a@gmail.com"),
  new User('Krishna', 22, "b@gmail.com"),
  new User('Narendra', 31, "c@gmail.com")
];

}

