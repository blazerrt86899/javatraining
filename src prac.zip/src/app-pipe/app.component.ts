import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})


export class AppComponent {

str = "romu";
today = new Date();
color:string
size:number
visible:boolean
displayText:string
fontStyle:string
myclass = {
  'key':'any',
  'value':'any'
}
employee = {
  'id':1,
  'profile':{
    'one':'manager',
    'two':'trainee'
  }
}

constructor() { 
    this.color = 'green';
    this.size = 50;
    this.displayText = 'show-class';
    this.visible = true;
    this.fontStyle='normal';
  }
  
  // toggle() {
  //   this.visible = !this.visible;
  //   this.displayText = this.visible ? 'show-class' : 'hide-class';
  // }

}