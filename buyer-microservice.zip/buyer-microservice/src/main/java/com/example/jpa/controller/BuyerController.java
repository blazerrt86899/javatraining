package com.example.jpa.controller;

import com.example.jpa.exception.ResourceNotFoundException;
import com.example.jpa.model.Buyer;
import com.example.jpa.repository.BuyerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
public class BuyerController {

    @Autowired
    private BuyerRepository buyerRepository;

    @GetMapping("/posts")
    public Page<Buyer> getAllPosts(Pageable pageable) {
        return buyerRepository.findAll(pageable);
    }

    @PostMapping("/posts")
    public Buyer createPost(@Valid @RequestBody Buyer post) {
        return buyerRepository.save(post);
    }

    @PutMapping("/posts/{postId}")
    public Buyer updatePost(@PathVariable Long postId, @Valid @RequestBody Buyer postRequest) {
        return buyerRepository.findById(postId).map(post -> {
            post.setEmailId(postRequest.getEmailId());
            post.setMobileNumber(postRequest.getMobileNumber());
            post.setPassword(postRequest.getPassword());
            return buyerRepository.save(post);
        }).orElseThrow(() -> new ResourceNotFoundException("PostId " + postId + " not found"));
    }


    @DeleteMapping("/posts/{postId}")
    public ResponseEntity<?> deletePost(@PathVariable Long postId) {
        return buyerRepository.findById(postId).map(post -> {
        	buyerRepository.delete(post);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new ResourceNotFoundException("PostId " + postId + " not found"));
    }

}
