package com.example.jpa.repository;

import com.example.jpa.model.Cart;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Created by rajeevkumarsingh on 21/11/17.
 */
@Repository
public interface CartRepository extends JpaRepository<Cart, Long> {
    Page<Cart> findByBuyerId(Long postId, Pageable pageable);
    Optional<Cart> findByIdAndBuyerId(Long id, Long postId);
}
