package com.example.jpa.controller;

import com.example.jpa.exception.ResourceNotFoundException;
import com.example.jpa.model.NewComment;
import com.example.jpa.repository.BuyerRepository;
import com.example.jpa.repository.NewCommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
public class NewCommentController {

    @Autowired
    private NewCommentRepository newCommentRepository;

    @Autowired
    private BuyerRepository buyerRepository;

    @GetMapping("/posts/{postId}/newcomments")
    public Page<NewComment> getAllCommentsByPostId(@PathVariable (value = "postId") Long postId,
                                                Pageable pageable) {
        return newCommentRepository.findByBuyerId(postId, pageable);
    }

    @PostMapping("/posts/{postId}/newcomments")
    public NewComment createComment(@PathVariable (value = "postId") Long postId,
                                 @Valid @RequestBody NewComment comment) {
        return buyerRepository.findById(postId).map(buyer -> {
            comment.setBuyer(buyer);
            return newCommentRepository.save(comment);
        }).orElseThrow(() -> new ResourceNotFoundException("PostId " + postId + " not found"));
    }

    @PutMapping("/posts/{postId}/newcomments/{commentId}")
    public NewComment updateComment(@PathVariable (value = "postId") Long postId,
                                 @PathVariable (value = "commentId") Long commentId,
                                 @Valid @RequestBody NewComment commentRequest) {
        if(!buyerRepository.existsById(postId)) {
            throw new ResourceNotFoundException("PostId " + postId + " not found");
        }

        return newCommentRepository.findById(commentId).map(comment -> {
            comment.setText(commentRequest.getText());
            return newCommentRepository.save(comment);
        }).orElseThrow(() -> new ResourceNotFoundException("CommentId " + commentId + "not found"));
    }

    @DeleteMapping("/posts/{postId}/newcomments/{commentId}")
    public ResponseEntity<?> deleteComment(@PathVariable (value = "postId") Long postId,
                              @PathVariable (value = "commentId") Long commentId) {
        return newCommentRepository.findByIdAndBuyerId(commentId, postId).map(comment -> {
            newCommentRepository.delete(comment);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new ResourceNotFoundException("Comment not found with id " + commentId + " and postId " + postId));
    }
}
