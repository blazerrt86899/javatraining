package com.cts.springbootjpa;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyRestController {
	
	@Autowired
	private IPersonService service;
	
	@RequestMapping("getAll")
	public List<Person> getAll(){
		
		return service.getAllPersons();
	}
	
	@RequestMapping("getByName/{ename}")
	public Person getPersonByName(@PathVariable("ename") String name){
		
		return service.getByPersonName(name);
	}
	
//	@RequestMapping("getByNameAddr/{ename}/{addr}")
//	public Person getUsingNameAddress(@PathVariable("ename") String name, @PathVariable("addr") String ad) {
//		return service.findUsingNameAddress(name, ad);
//	}
	
	@RequestMapping(value = "/person", method = RequestMethod.POST, produces = "application/json")
	public Integer createOrUpdate (@RequestBody Person person) {
		
		return service.createOrUpdate(person);
	}
	
	@RequestMapping(value = "deleteById/{pid}", method = RequestMethod.DELETE)
	public void deleteById(@PathVariable("pid") Integer personId) {
		
		service.deleteById(personId);
	}
	
	@RequestMapping(value="/update", method = RequestMethod.PUT)
	public Person updatePerson(@RequestBody Person person) {
		
		return service.update(person);
	}
	
	@RequestMapping(value="/updateAddr", method = RequestMethod.PATCH)
	public Person updatePersonAddr(@RequestBody Person person) {
		
		return service.updateAddr(person);
	}
	
	
}
