package com.cts.hibernate.HibernateBasics;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

public class App 
{
    public static void main( String[] args ) {  
    	
    	Configuration configuration = new Configuration().configure();
    	StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties());
    	SessionFactory factory = configuration.buildSessionFactory(builder.build());
    	Session session = factory.openSession();
    	Employee employee = new Employee(1005,"Renu"
    			+ ""
    			+ "","Manager");
    	session.beginTransaction();
    	//Serializable object = session.save(employee);
    	//employee.setDesign("Sr Manager");
    	//System.out.println(employee);
    	
    	//Employee employee = (Employee)session.get(Employee.class, 1005);
    	session.evict(employee);
    	//employee.setDesign("Techie");
    	session.update(employee);
    	//session.flush();
    	//session.delete(employee);
    	session.getTransaction().commit();
    	//System.out.println(object);
    	session.close();
    	
    	
    	
}
    
}
