package com.egg.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.BuyerRepository;
import com.egg.dao.TransactionRepository;
import com.egg.model.TransactionHistory;



@Service
public class TransactionService {

	@Autowired
	private TransactionRepository transactionHistory;

	@Autowired
	private BuyerRepository buyerRepository;

	public Optional<TransactionHistory> addCartItem(TransactionHistory transaction, Integer buyerId) {
		return buyerRepository.findById(buyerId).map(buyer -> {
			transaction.setBuyerId(buyer);
			return transactionHistory.save(transaction);
		});

	}

}
