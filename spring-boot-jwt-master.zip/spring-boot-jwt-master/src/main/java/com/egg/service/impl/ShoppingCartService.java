package com.egg.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.BuyerRepository;
import com.egg.dao.CartRepository;
import com.egg.dao.ItemRepository;
import com.egg.dao.PurchaseRepository;
import com.egg.dao.TransactionRepository;
import com.egg.model.Buyer;
import com.egg.model.ItemInventory;
import com.egg.model.PurchaseHistory;
import com.egg.model.ShoppingCart;
import com.egg.model.TransactionHistory;



@Service
public class ShoppingCartService {
	
	@Autowired
	private CartRepository cartRepository;
	
	@Autowired
	private BuyerRepository buyerRepository;
	
	@Autowired
	private ItemRepository itemrepository;
	
	@Autowired
	private TransactionRepository transactionRepository;
	
	@Autowired
	private PurchaseRepository purchaseRepository;
//	public List<ShoppingCart> getAllCartItems(Integer buyerId){
//		return cartRepository.findAllByBuyerId(buyerId);
//	}
	public List<ShoppingCart> getAllCartItems(Integer buyerId){
		return cartRepository.getAllCartItems(buyerId);
	}
	
	public Optional<ShoppingCart> addCartItem(ShoppingCart shoppingCartItem, Integer buyerId) {
		return buyerRepository.findById(buyerId).map(buyer -> {
			shoppingCartItem.setBuyerId(buyer);
			return cartRepository.save(shoppingCartItem);
		});
		
	}
	
	public String deleteCartItemById(Integer cartItemId) {
		cartRepository.deleteById(cartItemId);
		return "Item with cartId "+cartItemId+" is deleted.";
	}
	
	public void emptyCart(Integer buyerId) {
		//Optional<Buyer> buyerInfo = buyerRepository.findById(buyerId);
		cartRepository.emptyCart(buyerId);
	}
	
	public ShoppingCart updateCart(ShoppingCart shoppingCartItem,Integer cartItemId) {
		ShoppingCart newCart = null;
		Optional<ShoppingCart> cartItem = cartRepository.findById(cartItemId);
		
		if(cartItem.isPresent()) {
		newCart = cartItem.get();
		newCart.setItemQuantity(shoppingCartItem.getItemQuantity());
		
		return cartRepository.save(newCart);
		}
		
		return null;
		
	}
	
	
	public String checkoutCart(Integer buyerId) {
		Double totalAmount = 0.00;
		TransactionHistory transaction = null;
		PurchaseHistory purchaseHistory = null;
		ItemInventory cartItem = null;
		//Integer iter = 0;
		List<ShoppingCart> getAllCart = cartRepository.getAllCartItems(buyerId);
		for(ShoppingCart cart : getAllCart) {
			Optional<ItemInventory> item = itemrepository.findById(cart.getItemId());
			totalAmount += item.get().getItemPrice();
		}
		Optional<Buyer> buyer  = buyerRepository.findById(buyerId);
		transaction = new TransactionHistory();
		transaction.setBuyerId(buyer.get());
		transaction.setTotalAmount(totalAmount);
		transaction.setTransactionType("Debited");
		transaction.setTransactionRemarks("PaymentDone");

		transactionRepository.save(transaction);


		for(ShoppingCart cart : getAllCart) {
			//System.out.println(iter++);
			purchaseHistory = new PurchaseHistory();
			purchaseHistory.setTransactionHistory(transaction);
			purchaseHistory.setItemId(cart.getItemId());
			purchaseHistory.setBuyerId(buyer.get());
			purchaseHistory.setPurchaseRemarks("purchased");
			purchaseHistory.setNumberOfItems(cart.getItemQuantity());

			purchaseRepository.save(purchaseHistory);

			cartItem = new ItemInventory();
			Optional<ItemInventory> newitem = itemrepository.findById(cart.getItemId());
			cartItem = newitem.get();
			Long quantity = cartItem.getItemStockNumber();
			cartItem.setItemStockNumber(quantity-cart.getItemQuantity());

			itemrepository.save(cartItem);

		}

		cartRepository.emptyCart(buyerId);

		return "Successful";
	}

	

}
